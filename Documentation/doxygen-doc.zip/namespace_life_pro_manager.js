var namespace_life_pro_manager =
[
    [ "DBConnection", "class_life_pro_manager_1_1_d_b_connection.html", "class_life_pro_manager_1_1_d_b_connection" ],
    [ "frmAddTask", "class_life_pro_manager_1_1frm_add_task.html", "class_life_pro_manager_1_1frm_add_task" ],
    [ "frmAddTopic", "class_life_pro_manager_1_1frm_add_topic.html", "class_life_pro_manager_1_1frm_add_topic" ],
    [ "frmEditTask", "class_life_pro_manager_1_1frm_edit_task.html", "class_life_pro_manager_1_1frm_edit_task" ],
    [ "frmMain", "class_life_pro_manager_1_1frm_main.html", "class_life_pro_manager_1_1frm_main" ],
    [ "Lists", "class_life_pro_manager_1_1_lists.html", "class_life_pro_manager_1_1_lists" ],
    [ "Tasks", "class_life_pro_manager_1_1_tasks.html", "class_life_pro_manager_1_1_tasks" ],
    [ "TaskSelections", "class_life_pro_manager_1_1_task_selections.html", "class_life_pro_manager_1_1_task_selections" ]
];