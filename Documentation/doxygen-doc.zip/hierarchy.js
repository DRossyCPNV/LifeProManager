var hierarchy =
[
    [ "LifeProManager.DBConnection", "class_life_pro_manager_1_1_d_b_connection.html", null ],
    [ "Form", null, [
      [ "LifeProManager.frmAddTask", "class_life_pro_manager_1_1frm_add_task.html", null ],
      [ "LifeProManager.frmAddTopic", "class_life_pro_manager_1_1frm_add_topic.html", null ],
      [ "LifeProManager.frmEditTask", "class_life_pro_manager_1_1frm_edit_task.html", null ],
      [ "LifeProManager.frmMain", "class_life_pro_manager_1_1frm_main.html", null ]
    ] ],
    [ "LifeProManager.Lists", "class_life_pro_manager_1_1_lists.html", null ],
    [ "LifeProManager.Tasks", "class_life_pro_manager_1_1_tasks.html", null ],
    [ "LifeProManager.TaskSelections", "class_life_pro_manager_1_1_task_selections.html", null ]
];