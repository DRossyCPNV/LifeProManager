var class_life_pro_manager_1_1_tasks =
[
    [ "Deadline", "class_life_pro_manager_1_1_tasks.html#af93a3c38f097a66823aee1d6f924927f", null ],
    [ "Description", "class_life_pro_manager_1_1_tasks.html#ab3c7bbfe1bdfc5e9fa048e26646a9be9", null ],
    [ "Id", "class_life_pro_manager_1_1_tasks.html#a612510860a7c5d944f34be54c0a44eef", null ],
    [ "Lists_id", "class_life_pro_manager_1_1_tasks.html#a71aec4c4b000b3bd236fedb54b20805c", null ],
    [ "Priority_id", "class_life_pro_manager_1_1_tasks.html#a52619cd01896a53d1fc1416038a4e2bc", null ],
    [ "Status_id", "class_life_pro_manager_1_1_tasks.html#afa359d3c739879d6ae599b156a505576", null ],
    [ "Title", "class_life_pro_manager_1_1_tasks.html#a399b1ee76664ef65fd2589dbd467392a", null ],
    [ "ValidationDate", "class_life_pro_manager_1_1_tasks.html#a8803d537bda8724a661157ca7b8e02f4", null ]
];