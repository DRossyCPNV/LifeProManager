var searchData=
[
  ['readapprovedtask_74',['ReadApprovedTask',['../class_life_pro_manager_1_1_d_b_connection.html#a37e252e98d7bb37b732142b33b7f05f2',1,'LifeProManager::DBConnection']]],
  ['readdatafordeadlines_75',['ReadDataForDeadlines',['../class_life_pro_manager_1_1_d_b_connection.html#ac87e3e2dd846478cf2e641bb8eeea83a',1,'LifeProManager::DBConnection']]],
  ['readprioritiesdenomination_76',['ReadPrioritiesDenomination',['../class_life_pro_manager_1_1_d_b_connection.html#a30aecf2f80a430c5a4131bfee41ff204',1,'LifeProManager::DBConnection']]],
  ['readsetting_77',['ReadSetting',['../class_life_pro_manager_1_1_d_b_connection.html#a0e52800b9fff10d56a102b7478ee14c3',1,'LifeProManager::DBConnection']]],
  ['readstatusdenomination_78',['ReadStatusDenomination',['../class_life_pro_manager_1_1_d_b_connection.html#a8bfded55953f3540aa43fc4af61f1247',1,'LifeProManager::DBConnection']]],
  ['readtask_79',['ReadTask',['../class_life_pro_manager_1_1_d_b_connection.html#af250adb16bd1e56b175e27cbd1d37a92',1,'LifeProManager::DBConnection']]],
  ['readtaskfordate_80',['ReadTaskForDate',['../class_life_pro_manager_1_1_d_b_connection.html#a407cdc49b1e682a4d1f238ad2aad3d79',1,'LifeProManager::DBConnection']]],
  ['readtaskfordateplusseven_81',['ReadTaskForDatePlusSeven',['../class_life_pro_manager_1_1_d_b_connection.html#ab3f10f2a32a5ea7e6f8202a43ac198dd',1,'LifeProManager::DBConnection']]],
  ['readtaskfortopic_82',['ReadTaskForTopic',['../class_life_pro_manager_1_1_d_b_connection.html#a98223acda14339ef7f63fba22223cc8c',1,'LifeProManager::DBConnection']]],
  ['readtopics_83',['ReadTopics',['../class_life_pro_manager_1_1_d_b_connection.html#ac09718471963ed6978600c5f76481027',1,'LifeProManager::DBConnection']]],
  ['refreshselectedtask_84',['RefreshSelectedTask',['../class_life_pro_manager_1_1frm_main.html#a5b933b8fe5b268c2aa5b3ea1c9d64c9e',1,'LifeProManager::frmMain']]]
];
