var searchData=
[
  ['tasks_50',['Tasks',['../class_life_pro_manager_1_1_tasks.html',1,'LifeProManager']]],
  ['taskselections_51',['TaskSelections',['../class_life_pro_manager_1_1_task_selections.html',1,'LifeProManager']]]
];
