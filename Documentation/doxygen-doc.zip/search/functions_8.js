var searchData=
[
  ['unapprovetask_86',['UnapproveTask',['../class_life_pro_manager_1_1_d_b_connection.html#a00b204198e9b72149ecfc03307e35fda',1,'LifeProManager::DBConnection']]],
  ['updatesetting_87',['UpdateSetting',['../class_life_pro_manager_1_1_d_b_connection.html#a057984b808b8eaf12430ccce4e14d6ec',1,'LifeProManager::DBConnection']]]
];
