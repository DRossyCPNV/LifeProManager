var searchData=
[
  ['lifepromanager_52',['LifeProManager',['../namespace_life_pro_manager.html',1,'']]],
  ['properties_53',['Properties',['../namespace_life_pro_manager_1_1_properties.html',1,'LifeProManager']]]
];
