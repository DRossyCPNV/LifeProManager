var searchData=
[
  ['edittask_64',['EditTask',['../class_life_pro_manager_1_1_d_b_connection.html#a7c90e1e89bea794b60661c4773fcd6e2',1,'LifeProManager::DBConnection']]]
];
