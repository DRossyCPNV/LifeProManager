var searchData=
[
  ['approvetask_0',['ApproveTask',['../class_life_pro_manager_1_1_d_b_connection.html#a8c7b9a47ae72005f9e483a13bdd5f0e6',1,'LifeProManager::DBConnection']]]
];
