var searchData=
[
  ['insertinitialdata_16',['InsertInitialData',['../class_life_pro_manager_1_1_d_b_connection.html#a3ba2dbf15c087456e4553a935b864dc6',1,'LifeProManager::DBConnection']]],
  ['inserttask_17',['InsertTask',['../class_life_pro_manager_1_1_d_b_connection.html#abb683de322e2fdcc70d2b54cfddc25f2',1,'LifeProManager::DBConnection']]],
  ['inserttopic_18',['InsertTopic',['../class_life_pro_manager_1_1_d_b_connection.html#a985c3b055d0afa1c1c5aef66b2ec975c',1,'LifeProManager::DBConnection']]]
];
