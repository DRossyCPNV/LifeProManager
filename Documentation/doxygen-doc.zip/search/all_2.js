var searchData=
[
  ['dbconnection_7',['DBConnection',['../class_life_pro_manager_1_1_d_b_connection.html',1,'LifeProManager']]],
  ['deletetask_8',['DeleteTask',['../class_life_pro_manager_1_1_d_b_connection.html#a56fd420f40e97419cb015fd9e0e3d389',1,'LifeProManager::DBConnection']]],
  ['deletetopic_9',['DeleteTopic',['../class_life_pro_manager_1_1_d_b_connection.html#a79a77b310650bfba54b3956aee20fefc',1,'LifeProManager::DBConnection']]],
  ['dispose_10',['Dispose',['../class_life_pro_manager_1_1frm_add_task.html#a63ac2cc4755d1dd3b5fa5eeffde43b80',1,'LifeProManager.frmAddTask.Dispose()'],['../class_life_pro_manager_1_1frm_add_topic.html#a7ed7b26031bec91347ccb8f7eeee9eb7',1,'LifeProManager.frmAddTopic.Dispose()'],['../class_life_pro_manager_1_1frm_edit_task.html#a4d195e665f765b8aba1ca7691cc9dc71',1,'LifeProManager.frmEditTask.Dispose()'],['../class_life_pro_manager_1_1frm_main.html#a6d2427087610dd7ac16ec888851c53bb',1,'LifeProManager.frmMain.Dispose()']]]
];
