var searchData=
[
  ['tasks_39',['Tasks',['../class_life_pro_manager_1_1_tasks.html',1,'LifeProManager']]],
  ['taskselections_40',['TaskSelections',['../class_life_pro_manager_1_1_task_selections.html',1,'LifeProManager']]],
  ['translateappui_41',['TranslateAppUI',['../class_life_pro_manager_1_1frm_main.html#ab674bf6f679c66d9e5130c2c3497defc',1,'LifeProManager::frmMain']]]
];
