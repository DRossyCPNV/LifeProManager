var searchData=
[
  ['translateappui_85',['TranslateAppUI',['../class_life_pro_manager_1_1frm_main.html#ab674bf6f679c66d9e5130c2c3497defc',1,'LifeProManager::frmMain']]]
];
