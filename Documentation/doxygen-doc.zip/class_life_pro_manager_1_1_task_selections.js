var class_life_pro_manager_1_1_task_selections =
[
    [ "Task_id", "class_life_pro_manager_1_1_task_selections.html#a2d2005ca028f43ad7ea757db5801a711", null ],
    [ "Task_information", "class_life_pro_manager_1_1_task_selections.html#a33c430f7aa9733982f39fc165b4eb1fd", null ],
    [ "Task_label", "class_life_pro_manager_1_1_task_selections.html#a6c75faf2740c12a361654f48b126612c", null ]
];