var class_life_pro_manager_1_1frm_main =
[
    [ "frmMain", "class_life_pro_manager_1_1frm_main.html#a0b2b9ecadfdf6066d06ab83fe06ea7bf", null ],
    [ "CreateTasksLayout", "class_life_pro_manager_1_1frm_main.html#afc131d137acc98044dc3cebc5ef12660", null ],
    [ "Dispose", "class_life_pro_manager_1_1frm_main.html#a6d2427087610dd7ac16ec888851c53bb", null ],
    [ "LoadDoneTasks", "class_life_pro_manager_1_1frm_main.html#a861b129dafa35adf8d37accfb9220ac7", null ],
    [ "LoadTasks", "class_life_pro_manager_1_1frm_main.html#a1879e8d2c7a0430769dcfd41c75764c8", null ],
    [ "LoadTasksForDate", "class_life_pro_manager_1_1frm_main.html#aad4fa7224740326f4b37e3ac08a5da99", null ],
    [ "LoadTasksForTodayPlusSeven", "class_life_pro_manager_1_1frm_main.html#ac41382a457734b01b7ca73e1bb3ae564", null ],
    [ "LoadTasksInTopic", "class_life_pro_manager_1_1frm_main.html#a5dc2f59424b9b6a68fea8b68bd94d372", null ],
    [ "LoadTopics", "class_life_pro_manager_1_1frm_main.html#a8b05d5366feb1cffb781f5aa7ea7f94a", null ],
    [ "RefreshSelectedTask", "class_life_pro_manager_1_1frm_main.html#a5b933b8fe5b268c2aa5b3ea1c9d64c9e", null ],
    [ "TranslateAppUI", "class_life_pro_manager_1_1frm_main.html#ab674bf6f679c66d9e5130c2c3497defc", null ],
    [ "cboTopics", "class_life_pro_manager_1_1frm_main.html#a7eddbe50c218a1b50868884cb932c4d5", null ],
    [ "SelectedDate", "class_life_pro_manager_1_1frm_main.html#a55f7e3147d7ab7c2500a290b47e3fc29", null ],
    [ "SelectedDateTypeTime", "class_life_pro_manager_1_1frm_main.html#a2605ef381fc478cb0f3d86a6d744bd14", null ]
];