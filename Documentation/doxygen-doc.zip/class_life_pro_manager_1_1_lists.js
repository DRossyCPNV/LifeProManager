var class_life_pro_manager_1_1_lists =
[
    [ "Id", "class_life_pro_manager_1_1_lists.html#ac6dfef3ebbcf2711bfc0fca6a3616f5f", null ],
    [ "Title", "class_life_pro_manager_1_1_lists.html#a9ebe4bbbd7c99074518c556891e3f495", null ]
];