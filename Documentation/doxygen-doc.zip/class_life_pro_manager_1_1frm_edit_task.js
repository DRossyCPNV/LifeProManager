var class_life_pro_manager_1_1frm_edit_task =
[
    [ "frmEditTask", "class_life_pro_manager_1_1frm_edit_task.html#a7d4431c4876961f2fb5206f5d5e1d92d", null ],
    [ "Dispose", "class_life_pro_manager_1_1frm_edit_task.html#a4d195e665f765b8aba1ca7691cc9dc71", null ],
    [ "lblName", "class_life_pro_manager_1_1frm_edit_task.html#ac01b00048adda9507e82fa3db65a234c", null ]
];