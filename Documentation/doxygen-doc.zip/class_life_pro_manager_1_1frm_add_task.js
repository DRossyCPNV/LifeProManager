var class_life_pro_manager_1_1frm_add_task =
[
    [ "frmAddTask", "class_life_pro_manager_1_1frm_add_task.html#acbcf786830a95ffe2034950e9d4fe1b5", null ],
    [ "Dispose", "class_life_pro_manager_1_1frm_add_task.html#a63ac2cc4755d1dd3b5fa5eeffde43b80", null ],
    [ "lblName", "class_life_pro_manager_1_1frm_add_task.html#acb5fac58a06b9b431d2ab91740ae95e0", null ]
];